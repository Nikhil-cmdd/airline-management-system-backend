package com.accelerate.Airline.dto;

public record LoginResponseDto(
        String username,
        String password
) {

}
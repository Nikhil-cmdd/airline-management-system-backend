package com.accelerate.Airline.enums;

public enum Role {
    EMPLOYEE,PASSENGER
}

package com.accelerate.Airline.enums;

public enum JobTitle {
    CAPTAIN, ASST_CAPTAIN
}

package com.accelerate.Airline.dto;

public record ErrorMessageDto(
        String message
        //String status
) {
}

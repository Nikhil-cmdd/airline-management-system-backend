package com.accelerate.Airline.dto;

public record UserReqDto(
        String username,
        String password
) {
}
package com.accelerate.Airline.enums;

public enum SeatType {
    WINDOW, AISLE, MIDDLE
}
